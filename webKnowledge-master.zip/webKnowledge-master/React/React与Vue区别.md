# React与Vue区别

 - 上手
   - vue - easy 官方做了很多,CSS script
   - react ，上手偏难，
 - 数据绑定
   - vue model双向的
   - react是单向的
 - 模板
   - vue H5模板
   - react JSX
 - api
   - vue 多，计算属性，watch 这种神器
   - react 少，更多功能留给社区，比如写个函数还有bind以下
 - 应用
   - vue 适合面向用户的，复杂度稍低一些的
   - react 复杂的
 - 测试
   - react 函数式编程利于测试