# 路由
React中路由主要有两种方式：
 - hash路由
 - history路由

[react-router原理](https://blog.csdn.net/qq_36223144/article/details/83247008)