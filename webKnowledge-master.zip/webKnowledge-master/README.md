# 前端面试题总结

我是2020届的前端，这是我平时收集整理的知识点和面试题，查漏补缺，扎实基础，更像是一个文档，而且**不断更新中！！！**

**star**一个表鼓励，也不容易搞丢链接哦!

有疑问的同学也可以加我**微信**： purple12369


### [CSS](CSS/README.md)

### [HTML](HTML/README.md)

### [JS基础](JS基础/README.md)

### [编程题与分析题](编程题与分析题/README.md)

### [React](React/README.md)

### [网络知识](网络/README.md)

### [Web安全](Web安全/README.md)

### [性能优化](性能优化/README.md)

### TODO
 - 页面加载时何时会阻塞？ 关系是怎样
 - 懒加载
 - Ajax怎么带cookie
 - redux
   - setstate怎么实现异步的哪
 - 前端路由怎么做，原理是什么 
 - LocalStorage